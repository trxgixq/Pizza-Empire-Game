PIZZA EMPIRE — WINDOWS EDITION

HOW TO PLAY
1. Extract the entire ZIP to a folder.
2. Double-click START-PIZZA-EMPIRE.bat.
3. The game opens in your default web browser.

No Python or installer is required. A modern browser is required. Progress is saved in that browser on this PC.

NOTE
This is a browser-based Windows-compatible edition, not a native Windows .exe. The ZIP you provided contained only a compiled macOS Apple Silicon app and bundled game data, not the original Python source code, so the original app could not be rebuilt as a native Windows executable.
